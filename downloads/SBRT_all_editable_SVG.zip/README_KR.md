# SBRT 개별 SVG 모음

## 폴더

- 01_fields: A–D 분야 아이콘 4개와 monochrome 폴더의 흑백 버전 4개
- 02_stages: Define, Ideate, Evaluate, Deliver 아이콘 4개
- 03_actors: AI 칩, 디자이너 아이콘 2개
- 04_AI_role_diagrams: Generator, Assistant, Advisor, Co-creator 관계 도식 4개
- 05_designer_role_diagrams: Evaluator, Interpreter, Orchestrator, Value-creator 작용 도식 4개
- 06_primitives: 작업 대상, 방향 화살표, 주석선 3개
- 07_boards: v01–v03 전체 보드 SVG 7장. 이전 시안 보존용이며 모두 최종 채택안은 아니다.

총 32개의 SVG. 개별 요소 25개, 전체 보드 7개.

개별 SVG는 투명 배경이다. 분야 기호의 A–D 문자는 편집 가능한 텍스트다. 역할별 도식은 이름과 설명이 함께 들어 있으며 개체별로 편집하거나 텍스트를 지울 수 있다. 텍스트 글꼴은 Noto Sans CJK KR이다. 폰트 설치 및 프로그램의 SVG 가져오기 방식에 따라 텍스트 표시가 달라질 수 있다. 전체 보드에는 밝은 배경 사각형이 포함되어 있다.

역할별 도식은 개념 설명용이며 실제 대화 로그나 분야별 최적 조합이 아니다. 분야 A와 C의 형태는 추가 검토 대상으로 유지했다. 자세한 의도와 한계는 Graphic_rationale.md 참조.
