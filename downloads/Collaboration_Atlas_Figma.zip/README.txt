Figma: drag an SVG onto the canvas.
editable: live text; font substitution may occur.
outlined: text converted to editable vector paths; recommended for preserving appearance.
CSS and pattern dependencies removed. Figma import has not been directly verified.
