Updated from the latest uploaded CollaboAtlasLogo.ai. Header includes DESIGNER x AI; main uses upper wordmark only. Original sRGB orange #E94B29. Black changes to off-white in dark version.
