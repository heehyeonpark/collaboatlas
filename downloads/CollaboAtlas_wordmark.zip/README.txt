CollaboAtlas / wordmark draft
Light and dark variants have transparent backgrounds.
Editable SVG: live text with letter spacing. Outlined SVG: editable vector paths.
App uses live HTML text so the browser font can differ slightly.
